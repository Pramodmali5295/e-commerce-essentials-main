export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  discount?: number;
  category: string;
  subCategory: string;
  images: string[];
  rating: number;
  reviewCount: number;
  inStock: boolean;
  stockCount: number;
  variants?: { type: string; options: string[] }[];
  tags: string[];
  isFeatured?: boolean;
  isTrending?: boolean;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  subCategories: string[];
  productCount: number;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  ctaText: string;
  ctaLink: string;
  bgGradient: string;
}

export interface Testimonial {
  id: string;
  name: string;
  avatar: string;
  rating: number;
  text: string;
  product: string;
}

export const categories: Category[] = [
  { id: "electronics", name: "Electronics", icon: "Smartphone", subCategories: ["Phones", "Laptops", "Audio", "Cameras"], productCount: 245 },
  { id: "fashion", name: "Fashion", icon: "Shirt", subCategories: ["Men", "Women", "Kids", "Accessories"], productCount: 892 },
  { id: "home", name: "Home & Living", icon: "Home", subCategories: ["Furniture", "Decor", "Kitchen", "Bedding"], productCount: 534 },
  { id: "beauty", name: "Beauty", icon: "Sparkles", subCategories: ["Skincare", "Makeup", "Fragrance", "Hair Care"], productCount: 312 },
  { id: "sports", name: "Sports", icon: "Dumbbell", subCategories: ["Fitness", "Outdoor", "Sportswear", "Equipment"], productCount: 198 },
  { id: "books", name: "Books", icon: "BookOpen", subCategories: ["Fiction", "Non-Fiction", "Academic", "Comics"], productCount: 1024 },
];

export const products: Product[] = [
  {
    id: "1", name: "Premium Wireless Headphones", description: "Experience crystal-clear audio with active noise cancellation. Premium build with 30hr battery life.", price: 4999, originalPrice: 7999, discount: 38, category: "electronics", subCategory: "Audio",
    images: ["/placeholder.svg"], rating: 4.5, reviewCount: 2341, inStock: true, stockCount: 45,
    variants: [{ type: "Color", options: ["Midnight Black", "Pearl White", "Navy Blue"] }],
    tags: ["bestseller", "trending"], isFeatured: true, isTrending: true,
  },
  {
    id: "2", name: "Slim Fit Cotton Shirt", description: "Premium cotton slim fit shirt perfect for any occasion. Breathable and comfortable.", price: 1299, originalPrice: 2499, discount: 48, category: "fashion", subCategory: "Men",
    images: ["/placeholder.svg"], rating: 4.3, reviewCount: 876, inStock: true, stockCount: 120,
    variants: [{ type: "Size", options: ["S", "M", "L", "XL"] }, { type: "Color", options: ["White", "Sky Blue", "Navy"] }],
    tags: ["trending"], isFeatured: true, isTrending: true,
  },
  {
    id: "3", name: "Smart Fitness Watch", description: "Track your health with precision. Heart rate, SpO2, sleep tracking and 14-day battery.", price: 3499, originalPrice: 5999, discount: 42, category: "electronics", subCategory: "Phones",
    images: ["/placeholder.svg"], rating: 4.6, reviewCount: 3210, inStock: true, stockCount: 78,
    variants: [{ type: "Color", options: ["Black", "Green", "Rose Gold"] }],
    tags: ["bestseller"], isFeatured: true, isTrending: true,
  },
  {
    id: "4", name: "Ergonomic Office Chair", description: "Designed for all-day comfort with lumbar support and adjustable armrests.", price: 12999, originalPrice: 18999, discount: 32, category: "home", subCategory: "Furniture",
    images: ["/placeholder.svg"], rating: 4.4, reviewCount: 567, inStock: true, stockCount: 23,
    variants: [{ type: "Color", options: ["Black", "Grey", "Blue"] }],
    tags: ["featured"], isFeatured: true,
  },
  {
    id: "5", name: "Natural Glow Serum", description: "Vitamin C enriched serum for radiant, youthful skin. Dermatologically tested.", price: 899, originalPrice: 1599, discount: 44, category: "beauty", subCategory: "Skincare",
    images: ["/placeholder.svg"], rating: 4.7, reviewCount: 4521, inStock: true, stockCount: 200,
    tags: ["bestseller", "trending"], isTrending: true,
  },
  {
    id: "6", name: "Running Shoes Pro", description: "Lightweight, responsive cushioning for your daily run. Breathable mesh upper.", price: 2999, originalPrice: 4999, discount: 40, category: "sports", subCategory: "Sportswear",
    images: ["/placeholder.svg"], rating: 4.5, reviewCount: 1890, inStock: true, stockCount: 65,
    variants: [{ type: "Size", options: ["7", "8", "9", "10", "11"] }, { type: "Color", options: ["Black/Red", "White/Blue", "Grey"] }],
    tags: ["trending"], isTrending: true,
  },
  {
    id: "7", name: "Bluetooth Speaker Mini", description: "Compact speaker with powerful bass. IPX7 waterproof, 12hr playtime.", price: 1999, originalPrice: 3499, discount: 43, category: "electronics", subCategory: "Audio",
    images: ["/placeholder.svg"], rating: 4.2, reviewCount: 1234, inStock: true, stockCount: 90,
    variants: [{ type: "Color", options: ["Black", "Red", "Teal"] }],
    tags: ["featured"], isFeatured: true,
  },
  {
    id: "8", name: "Designer Handbag", description: "Elegant leather handbag with premium finish. Spacious compartments.", price: 3999, originalPrice: 6999, discount: 43, category: "fashion", subCategory: "Accessories",
    images: ["/placeholder.svg"], rating: 4.6, reviewCount: 432, inStock: true, stockCount: 15,
    variants: [{ type: "Color", options: ["Tan", "Black", "Burgundy"] }],
    tags: ["premium"], isFeatured: true,
  },
  {
    id: "9", name: "Ceramic Dinner Set", description: "12-piece premium ceramic dinner set. Microwave and dishwasher safe.", price: 2499, originalPrice: 3999, discount: 38, category: "home", subCategory: "Kitchen",
    images: ["/placeholder.svg"], rating: 4.3, reviewCount: 289, inStock: true, stockCount: 34,
    tags: ["featured"],
  },
  {
    id: "10", name: "Yoga Mat Premium", description: "Extra thick, non-slip yoga mat. Eco-friendly TPE material.", price: 999, originalPrice: 1799, discount: 44, category: "sports", subCategory: "Fitness",
    images: ["/placeholder.svg"], rating: 4.4, reviewCount: 876, inStock: false, stockCount: 0,
    tags: ["popular"],
  },
  {
    id: "11", name: "Aromatic Candle Set", description: "Set of 3 luxury scented candles. Soy wax, 40hr burn time each.", price: 799, originalPrice: 1299, discount: 38, category: "home", subCategory: "Decor",
    images: ["/placeholder.svg"], rating: 4.5, reviewCount: 654, inStock: true, stockCount: 88,
    tags: ["gifting"],
  },
  {
    id: "12", name: "Laptop Backpack", description: "Water-resistant laptop backpack with USB charging port. Fits 15.6\" laptops.", price: 1499, originalPrice: 2499, discount: 40, category: "fashion", subCategory: "Accessories",
    images: ["/placeholder.svg"], rating: 4.3, reviewCount: 1567, inStock: true, stockCount: 45,
    tags: ["bestseller"],
  },
];

export const banners: Banner[] = [
  { id: "1", title: "Summer Collection 2026", subtitle: "Up to 60% off on premium fashion", ctaText: "Shop Now", ctaLink: "/products?category=fashion", bgGradient: "gradient-hero" },
  { id: "2", title: "Tech Deals Week", subtitle: "Best prices on electronics", ctaText: "Explore Deals", ctaLink: "/products?category=electronics", bgGradient: "gradient-gold" },
  { id: "3", title: "Home Makeover Sale", subtitle: "Transform your space for less", ctaText: "Discover", ctaLink: "/products?category=home", bgGradient: "gradient-navy" },
];

export const testimonials: Testimonial[] = [
  { id: "1", name: "Priya Sharma", avatar: "PS", rating: 5, text: "Amazing quality products! The delivery was super fast and the packaging was premium. Will definitely shop again.", product: "Premium Wireless Headphones" },
  { id: "2", name: "Rahul Verma", avatar: "RV", rating: 5, text: "Best shopping experience ever. The prices are unbeatable and the customer service is top-notch.", product: "Smart Fitness Watch" },
  { id: "3", name: "Anita Desai", avatar: "AD", rating: 4, text: "Love the variety! Found exactly what I was looking for. The quality exceeded my expectations.", product: "Natural Glow Serum" },
  { id: "4", name: "Vikram Singh", avatar: "VS", rating: 5, text: "Great discounts and authentic products. The return policy is hassle-free too.", product: "Slim Fit Cotton Shirt" },
];
