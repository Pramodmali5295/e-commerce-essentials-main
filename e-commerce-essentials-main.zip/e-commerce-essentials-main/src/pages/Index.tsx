import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Star, TrendingUp, Truck, Shield, RotateCcw, Headphones, ChevronRight } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import { products, categories, testimonials, banners } from "@/data/products";

const Index = () => {
  const featuredProducts = products.filter((p) => p.isFeatured);
  const trendingProducts = products.filter((p) => p.isTrending);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="gradient-hero text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-72 h-72 rounded-full bg-accent/30 blur-3xl" />
          <div className="absolute bottom-10 left-10 w-96 h-96 rounded-full bg-accent/20 blur-3xl" />
        </div>
        <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
          <div className="max-w-2xl">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <span className="inline-block px-3 py-1 text-xs font-semibold gradient-gold text-primary rounded-full mb-4">
                🔥 Summer Sale — Up to 60% Off
              </span>
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-6xl font-display font-bold leading-tight mb-4"
            >
              Discover Products<br />
              <span className="text-accent">You'll Love</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg opacity-80 mb-8 max-w-lg"
            >
              Premium quality products at unbeatable prices. Free shipping on orders above ₹999.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap gap-3"
            >
              <Link to="/products" className="inline-flex items-center gap-2 px-6 py-3 gradient-gold text-primary font-semibold rounded-lg hover:opacity-90 transition-opacity">
                Shop Now <ArrowRight size={16} />
              </Link>
              <Link to="/products?category=fashion" className="inline-flex items-center gap-2 px-6 py-3 border border-primary-foreground/30 text-primary-foreground font-semibold rounded-lg hover:bg-primary-foreground/10 transition-colors">
                Explore Collections
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Trust bar */}
      <section className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Truck, label: "Free Shipping", sub: "On orders ₹999+" },
              { icon: Shield, label: "Secure Payment", sub: "100% protected" },
              { icon: RotateCcw, label: "Easy Returns", sub: "7-day return" },
              { icon: Headphones, label: "24/7 Support", sub: "Always available" },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-gold-light flex items-center justify-center flex-shrink-0">
                  <Icon size={18} className="text-accent" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{label}</p>
                  <p className="text-xs text-muted-foreground">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-display font-bold">Shop by Category</h2>
              <p className="text-muted-foreground text-sm mt-1">Find what you need</p>
            </div>
            <Link to="/products" className="text-sm font-medium text-accent hover:underline flex items-center gap-1">
              View All <ChevronRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((cat, i) => (
              <motion.div
                key={cat.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.06 }}
              >
                <Link
                  to={`/products?category=${cat.id}`}
                  className="group block p-5 bg-card rounded-xl border border-border hover:border-accent/30 hover:shadow-card-hover text-center transition-all duration-300"
                >
                  <div className="w-14 h-14 mx-auto rounded-xl bg-surface group-hover:bg-gold-light flex items-center justify-center mb-3 transition-colors">
                    <span className="text-2xl">
                      {cat.icon === "Smartphone" && "📱"}
                      {cat.icon === "Shirt" && "👔"}
                      {cat.icon === "Home" && "🏠"}
                      {cat.icon === "Sparkles" && "✨"}
                      {cat.icon === "Dumbbell" && "💪"}
                      {cat.icon === "BookOpen" && "📚"}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold group-hover:text-accent transition-colors">{cat.name}</h3>
                  <p className="text-xs text-muted-foreground mt-0.5">{cat.productCount} products</p>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Offer banner */}
      <section className="py-4">
        <div className="container mx-auto px-4">
          <div className="gradient-gold rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-primary/60">Limited Time</span>
              <h3 className="text-2xl md:text-3xl font-display font-bold text-primary mt-1">Mega Electronics Sale</h3>
              <p className="text-primary/70 mt-1">Up to 50% off on headphones, watches & more</p>
            </div>
            <Link to="/products?category=electronics" className="px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:opacity-90 transition-opacity whitespace-nowrap">
              Shop Electronics
            </Link>
          </div>
        </div>
      </section>

      {/* Trending */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-2">
              <TrendingUp size={22} className="text-accent" />
              <div>
                <h2 className="text-2xl md:text-3xl font-display font-bold">Trending Now</h2>
                <p className="text-muted-foreground text-sm mt-0.5">What everyone's buying</p>
              </div>
            </div>
            <Link to="/products" className="text-sm font-medium text-accent hover:underline flex items-center gap-1">
              See All <ChevronRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {trendingProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="py-12 md:py-16 bg-surface">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-display font-bold">Featured Products</h2>
              <p className="text-muted-foreground text-sm mt-0.5">Hand-picked for you</p>
            </div>
            <Link to="/products" className="text-sm font-medium text-accent hover:underline flex items-center gap-1">
              View All <ChevronRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {featuredProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-display font-bold">What Our Customers Say</h2>
            <p className="text-muted-foreground text-sm mt-1">Real reviews from real people</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="bg-card p-5 rounded-xl border border-border"
              >
                <div className="flex gap-0.5 mb-3">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} size={14} className={j < t.rating ? "text-star fill-star" : "text-muted"} />
                  ))}
                </div>
                <p className="text-sm leading-relaxed text-muted-foreground mb-4">"{t.text}"</p>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full gradient-navy flex items-center justify-center text-xs font-bold text-primary-foreground">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{t.name}</p>
                    <p className="text-xs text-muted-foreground">Bought {t.product}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-12 md:py-16 bg-surface">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-display font-bold mb-2">Get 10% Off Your First Order</h2>
          <p className="text-muted-foreground text-sm mb-6">Subscribe to our newsletter for exclusive offers</p>
          <div className="flex gap-2 max-w-md mx-auto">
            <input type="email" placeholder="Enter your email" className="flex-1 px-4 py-3 rounded-lg bg-card border border-border text-sm focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent" />
            <button className="px-6 py-3 gradient-gold text-primary font-semibold rounded-lg text-sm hover:opacity-90 transition-opacity">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
