import { Link } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

const Cart = () => {
  const { items, removeItem, updateQuantity, totalPrice, totalSavings, clearCart } = useCart();

  const deliveryCharge = totalPrice >= 999 ? 0 : 49;
  const gst = Math.round(totalPrice * 0.18);
  const grandTotal = totalPrice + deliveryCharge;

  if (items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4">
        <ShoppingBag size={64} className="text-muted-foreground/20 mb-4" />
        <h1 className="text-2xl font-display font-bold mb-2">Your cart is empty</h1>
        <p className="text-muted-foreground text-sm mb-6">Looks like you haven't added anything yet.</p>
        <Link to="/products" className="px-6 py-3 gradient-gold text-primary font-semibold rounded-lg hover:opacity-90 transition-opacity">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link to="/products" className="p-2 hover:bg-surface rounded-lg transition-colors">
            <ArrowLeft size={20} />
          </Link>
          <h1 className="text-2xl md:text-3xl font-display font-bold">Shopping Cart ({items.length})</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Items */}
          <div className="lg:col-span-2 space-y-3">
            {items.map((item) => (
              <motion.div key={item.product.id} layout className="flex gap-4 p-4 bg-card rounded-xl border border-border">
                <div className="w-24 h-24 bg-surface rounded-lg flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <Link to={`/product/${item.product.id}`} className="text-sm font-semibold hover:text-accent transition-colors line-clamp-1">
                    {item.product.name}
                  </Link>
                  <p className="text-xs text-muted-foreground capitalize mt-0.5">{item.product.category}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="font-bold">₹{item.product.price.toLocaleString("en-IN")}</span>
                    {item.product.originalPrice && (
                      <span className="text-xs text-muted-foreground line-through">₹{item.product.originalPrice.toLocaleString("en-IN")}</span>
                    )}
                    {item.product.discount && <span className="text-xs text-success font-semibold">{item.product.discount}% off</span>}
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-border rounded-lg">
                      <button onClick={() => updateQuantity(item.product.id, item.quantity - 1)} className="p-1.5 hover:bg-surface transition-colors">
                        <Minus size={14} />
                      </button>
                      <span className="px-3 text-sm font-semibold">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.product.id, item.quantity + 1)} className="p-1.5 hover:bg-surface transition-colors">
                        <Plus size={14} />
                      </button>
                    </div>
                    <button onClick={() => removeItem(item.product.id)} className="flex items-center gap-1 text-xs text-destructive hover:underline">
                      <Trash2 size={12} /> Remove
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-xl border border-border p-5 sticky top-24">
              <h2 className="font-display font-semibold text-lg mb-4">Order Summary</h2>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal ({items.length} items)</span>
                  <span className="font-medium">₹{totalPrice.toLocaleString("en-IN")}</span>
                </div>
                {totalSavings > 0 && (
                  <div className="flex justify-between text-success">
                    <span>Discount</span>
                    <span className="font-medium">-₹{totalSavings.toLocaleString("en-IN")}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">GST (18%)</span>
                  <span className="font-medium">₹{gst.toLocaleString("en-IN")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Delivery</span>
                  <span className={`font-medium ${deliveryCharge === 0 ? "text-success" : ""}`}>
                    {deliveryCharge === 0 ? "FREE" : `₹${deliveryCharge}`}
                  </span>
                </div>
                <div className="border-t border-border pt-3 flex justify-between">
                  <span className="font-display font-semibold text-base">Total</span>
                  <span className="font-display font-bold text-xl">₹{grandTotal.toLocaleString("en-IN")}</span>
                </div>
              </div>
              <button className="w-full mt-5 py-3 gradient-gold text-primary font-semibold rounded-lg hover:opacity-90 transition-opacity">
                Place Order
              </button>
              <p className="text-center text-xs text-muted-foreground mt-3">Secure checkout • 100% safe payment</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
