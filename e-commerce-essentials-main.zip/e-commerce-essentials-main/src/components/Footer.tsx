import { Link } from "react-router-dom";
import { categories } from "@/data/products";

const Footer = () => (
  <footer className="gradient-navy text-primary-foreground">
    <div className="container mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg gradient-gold flex items-center justify-center">
              <span className="text-sm font-bold text-primary">S</span>
            </div>
            <span className="text-xl font-display font-bold">ShopVista</span>
          </div>
          <p className="text-sm opacity-70 leading-relaxed mb-4">
            Your premium destination for quality products at unbeatable prices. Shop with confidence.
          </p>
          <div className="flex gap-3">
            {["f", "in", "tw", "ig"].map((s) => (
              <div key={s} className="w-8 h-8 rounded-full bg-primary-foreground/10 flex items-center justify-center text-xs font-bold hover:bg-accent hover:text-primary transition-colors cursor-pointer">
                {s}
              </div>
            ))}
          </div>
        </div>

        {/* Categories */}
        <div>
          <h4 className="font-display font-semibold mb-4">Categories</h4>
          <ul className="space-y-2">
            {categories.slice(0, 5).map((cat) => (
              <li key={cat.id}>
                <Link to={`/products?category=${cat.id}`} className="text-sm opacity-70 hover:opacity-100 hover:text-accent transition-all">
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Help */}
        <div>
          <h4 className="font-display font-semibold mb-4">Customer Service</h4>
          <ul className="space-y-2 text-sm opacity-70">
            <li className="hover:opacity-100 cursor-pointer transition-opacity">Contact Us</li>
            <li className="hover:opacity-100 cursor-pointer transition-opacity">FAQs</li>
            <li className="hover:opacity-100 cursor-pointer transition-opacity">Shipping & Returns</li>
            <li className="hover:opacity-100 cursor-pointer transition-opacity">Track Order</li>
            <li className="hover:opacity-100 cursor-pointer transition-opacity">Privacy Policy</li>
          </ul>
        </div>

        {/* Newsletter */}
        <div>
          <h4 className="font-display font-semibold mb-4">Stay Updated</h4>
          <p className="text-sm opacity-70 mb-3">Get exclusive offers and new arrivals in your inbox.</p>
          <div className="flex gap-2">
            <input type="email" placeholder="Your email" className="flex-1 px-3 py-2 text-sm rounded-lg bg-primary-foreground/10 border border-primary-foreground/20 focus:outline-none focus:border-accent text-primary-foreground placeholder:text-primary-foreground/40" />
            <button className="px-4 py-2 text-sm font-semibold gradient-gold text-primary rounded-lg hover:opacity-90 transition-opacity">
              Join
            </button>
          </div>
        </div>
      </div>

      <div className="mt-10 pt-6 border-t border-primary-foreground/10 text-center text-xs opacity-50">
        © 2026 ShopVista. All rights reserved. Made with ❤️ in India.
      </div>
    </div>
  </footer>
);

export default Footer;
